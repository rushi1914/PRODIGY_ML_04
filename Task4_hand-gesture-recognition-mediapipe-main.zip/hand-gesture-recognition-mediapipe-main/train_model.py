#!/usr/bin/env python3
"""
Hand Gesture Recognition - Model Training Script
Trains the keypoint classifier with the collected gesture data
"""

import csv
import numpy as np
import tensorflow as tf
from sklearn.model_selection import train_test_split
import os
from datetime import datetime

# Set random seed for reproducibility
RANDOM_SEED = 42

def train_keypoint_classifier():
    """Train the keypoint classifier model"""
    
    print("=" * 60)
    print("HAND GESTURE RECOGNITION - MODEL TRAINING")
    print("=" * 60)
    
    # Specify paths
    dataset = 'model/keypoint_classifier/keypoint.csv'
    model_save_path = 'model/keypoint_classifier/keypoint_classifier.keras'
    tflite_save_path = 'model/keypoint_classifier/keypoint_classifier.tflite'
    
    # Check if dataset exists
    if not os.path.exists(dataset):
        print(f"❌ Dataset not found: {dataset}")
        print("Please collect training data first using collect_data.py")
        return False
    
    # Count number of classes from the dataset
    print("📊 Analyzing dataset...")
    y_dataset = np.loadtxt(dataset, delimiter=',', dtype='int32', usecols=(0))
    unique_classes = np.unique(y_dataset)
    NUM_CLASSES = len(unique_classes)
    
    print(f"✅ Found {NUM_CLASSES} gesture classes: {list(unique_classes)}")
    
    # Load and analyze dataset
    print("\n📈 Loading dataset...")
    X_dataset = np.loadtxt(dataset, delimiter=',', dtype='float32', usecols=list(range(1, (21 * 2) + 1)))
    
    print(f"📊 Dataset shape: {X_dataset.shape}")
    print(f"📊 Labels shape: {y_dataset.shape}")
    
    # Show class distribution
    print("\n📊 Class distribution:")
    for class_id in unique_classes:
        count = np.sum(y_dataset == class_id)
        print(f"  Class {class_id}: {count} samples")
    
    # Split dataset
    print("\n🔄 Splitting dataset (75% train, 25% test)...")
    X_train, X_test, y_train, y_test = train_test_split(
        X_dataset, y_dataset, train_size=0.75, random_state=RANDOM_SEED
    )
    
    print(f"📊 Training samples: {X_train.shape[0]}")
    print(f"📊 Test samples: {X_test.shape[0]}")
    
    # Build model
    print("\n🏗️  Building model...")
    model = tf.keras.models.Sequential([
        tf.keras.layers.Input((21 * 2, )),
        tf.keras.layers.Dropout(0.2),
        tf.keras.layers.Dense(20, activation='relu'),
        tf.keras.layers.Dropout(0.4),
        tf.keras.layers.Dense(10, activation='relu'),
        tf.keras.layers.Dense(NUM_CLASSES, activation='softmax')
    ])
    
    # Compile model
    model.compile(
        optimizer='adam',
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )
    
    print("\n📋 Model summary:")
    model.summary()
    
    # Callbacks
    cp_callback = tf.keras.callbacks.ModelCheckpoint(
        model_save_path, 
        verbose=1, 
        save_weights_only=False,
        save_best_only=True,
        monitor='val_accuracy'
    )
    
    es_callback = tf.keras.callbacks.EarlyStopping(
        patience=20, 
        verbose=1,
        monitor='val_accuracy'
    )
    
    # Train model
    print("\n🚀 Starting training...")
    print("⏱️  This may take several minutes. Press Ctrl+C to stop early.")
    
    try:
        history = model.fit(
            X_train,
            y_train,
            epochs=1000,
            batch_size=128,
            validation_data=(X_test, y_test),
            callbacks=[cp_callback, es_callback],
            verbose=1
        )
        
        # Evaluate model
        print("\n📊 Evaluating model...")
        test_loss, test_accuracy = model.evaluate(X_test, y_test, verbose=0)
        print(f"✅ Test accuracy: {test_accuracy:.4f}")
        print(f"✅ Test loss: {test_loss:.4f}")
        
        # Convert to TensorFlow Lite
        print("\n🔄 Converting to TensorFlow Lite...")
        converter = tf.lite.TFLiteConverter.from_keras_model(model)
        tflite_model = converter.convert()
        
        with open(tflite_save_path, 'wb') as f:
            f.write(tflite_model)
        
        print(f"✅ Model saved to: {model_save_path}")
        print(f"✅ TensorFlow Lite model saved to: {tflite_save_path}")
        
        # Show final results
        print("\n" + "=" * 60)
        print("🎉 TRAINING COMPLETE!")
        print("=" * 60)
        print(f"📊 Final test accuracy: {test_accuracy:.2%}")
        print(f"📊 Final test loss: {test_loss:.4f}")
        print(f"📊 Number of classes: {NUM_CLASSES}")
        print(f"📊 Total training samples: {X_train.shape[0]}")
        print(f"📊 Total test samples: {X_test.shape[0]}")
        print("\n🚀 You can now run the application with: python app.py")
        
        return True
        
    except KeyboardInterrupt:
        print("\n⚠️  Training interrupted by user")
        return False
    except Exception as e:
        print(f"\n❌ Training failed: {str(e)}")
        return False

def main():
    """Main function"""
    print("Hand Gesture Recognition - Model Training")
    print("This script will train the keypoint classifier with your collected data.")
    print()
    
    # Check if we have the required dependencies
    try:
        import tensorflow as tf
        import sklearn
        print("✅ All required dependencies are available")
    except ImportError as e:
        print(f"❌ Missing dependency: {e}")
        print("Please install required packages: pip install tensorflow scikit-learn")
        return
    
    # Start training
    success = train_keypoint_classifier()
    
    if success:
        print("\n🎯 Next steps:")
        print("1. Test the model: python app.py")
        print("2. If accuracy is low, collect more training data")
        print("3. If needed, retrain with different parameters")
    else:
        print("\n❌ Training failed. Please check the error messages above.")

if __name__ == "__main__":
    main() 