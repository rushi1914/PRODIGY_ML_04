# How to Add New Hand Gestures

## Current Gestures
The system currently recognizes 4 gestures:
- **Class 0**: Open (Open hand)
- **Class 1**: Close (Closed fist)
- **Class 2**: Pointer (Pointing with index finger)
- **Class 3**: OK (Thumb and index finger forming a circle)

## Adding New Gestures

### Method 1: Using the Built-in Training Interface (Recommended)

1. **Start the application in training mode:**
   ```bash
   python app.py
   ```

2. **Enter keypoint logging mode:**
   - Press `k` to enter "MODE: Logging Key Point"
   - You'll see this displayed on screen

3. **Collect training data for new gestures:**
   - **For Thumb Up (Class 4):** Press `4` while showing a thumbs up gesture
   - **For Victory (Class 5):** Press `5` while showing a peace sign (✌️)
   - **For Palm (Class 6):** Press `6` while showing an open palm facing camera
   - **For Fist (Class 7):** Press `7` while showing a closed fist
   - **For Point (Class 8):** Press `8` while pointing with any finger
   - **For Rock (Class 9):** Press `9` while showing rock gesture (✊)

4. **Collect multiple samples:**
   - Show the gesture from different angles
   - Vary the hand position slightly
   - Collect at least 100-200 samples per gesture for good accuracy
   - The data is automatically saved to `model/keypoint_classifier/keypoint.csv`

### Method 2: Manual Data Collection

1. **Edit the labels file:**
   ```bash
   # Edit model/keypoint_classifier/keypoint_classifier_label.csv
   Open
   Close
   Pointer
   OK
   ThumbUp
   Victory
   Palm
   Fist
   Point
   Rock
   ```

2. **Collect data using the app:**
   - Run `python app.py`
   - Press `k` for keypoint logging mode
   - Use number keys 4-9 to collect data for new gestures

### Method 3: Direct CSV Editing (Advanced)

You can manually add data to `model/keypoint_classifier/keypoint.csv`:

```csv
4,0.1,0.2,0.3,...  # ThumbUp gesture data
4,0.15,0.25,0.35,...  # Another ThumbUp sample
5,0.2,0.3,0.4,...  # Victory gesture data
```

## Training the Model

After collecting data, you need to retrain the model:

1. **Open the training notebook:**
   ```bash
   jupyter notebook keypoint_classification.ipynb
   ```

2. **Update the number of classes:**
   - Find the line: `NUM_CLASSES = 4`
   - Change it to: `NUM_CLASSES = 10` (for 10 total gestures)

3. **Run the training:**
   - Execute all cells in the notebook
   - This will create a new `keypoint_classifier.tflite` model

## Gesture Suggestions

Here are some useful gestures you can add:

| Class | Gesture | Description | Use Case |
|-------|---------|-------------|----------|
| 4 | ThumbUp | 👍 | Approval, good job |
| 5 | Victory | ✌️ | Peace, number 2 |
| 6 | Palm | 🖐️ | Stop, open hand |
| 7 | Fist | ✊ | Rock, number 0 |
| 8 | Point | 👆 | Direction, selection |
| 9 | Rock | 🤘 | Rock on, number 3 |

## Tips for Better Recognition

1. **Consistent Lighting:** Train in similar lighting conditions
2. **Multiple Angles:** Show gestures from different angles
3. **Background Variation:** Train with different backgrounds
4. **Hand Position:** Vary hand position slightly during training
5. **Sample Count:** Aim for 200-500 samples per gesture
6. **Quality:** Ensure hand is clearly visible and well-lit

## Testing New Gestures

After training:

1. **Run the application:**
   ```bash
   python app.py
   ```

2. **Test gestures:**
   - Show the new gestures to the camera
   - Check if they're recognized correctly
   - If not, collect more training data

## Troubleshooting

### Poor Recognition
- Collect more training data
- Ensure consistent lighting
- Check hand visibility
- Retrain the model

### Model Not Updating
- Make sure to run the training notebook completely
- Check that `NUM_CLASSES` matches your label count
- Verify the new `.tflite` file was created

### Data Collection Issues
- Ensure you're in keypoint logging mode (press `k`)
- Check that data is being saved to the CSV file
- Verify camera is working properly

## Advanced Customization

You can also add custom gestures by:
- Modifying the preprocessing in `app.py`
- Adding gesture-specific logic
- Creating gesture combinations
- Adding gesture sequences

## Example: Adding "Thumb Up" Gesture

1. Start app: `python app.py`
2. Press `k` for keypoint logging
3. Press `4` and show thumbs up gesture 200+ times
4. Edit labels file to include "ThumbUp"
5. Update `NUM_CLASSES = 5` in training notebook
6. Run training notebook
7. Test the new gesture

This process can be repeated for any number of new gestures! 