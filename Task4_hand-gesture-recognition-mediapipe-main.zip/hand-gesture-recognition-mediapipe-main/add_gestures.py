#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Helper script to add new gestures to the hand gesture recognition system
"""

import os
import csv
import shutil
from datetime import datetime

def backup_existing_data():
    """Create a backup of existing training data"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Backup keypoint data
    if os.path.exists('model/keypoint_classifier/keypoint.csv'):
        backup_path = f'model/keypoint_classifier/keypoint_backup_{timestamp}.csv'
        shutil.copy2('model/keypoint_classifier/keypoint.csv', backup_path)
        print(f"✓ Backed up keypoint data to: {backup_path}")
    
    # Backup labels
    if os.path.exists('model/keypoint_classifier/keypoint_classifier_label.csv'):
        backup_path = f'model/keypoint_classifier/keypoint_classifier_label_backup_{timestamp}.csv'
        shutil.copy2('model/keypoint_classifier/keypoint_classifier_label.csv', backup_path)
        print(f"✓ Backed up labels to: {backup_path}")

def add_new_gesture_labels(new_gestures):
    """Add new gesture labels to the label file"""
    current_labels = []
    
    # Read existing labels
    try:
        with open('model/keypoint_classifier/keypoint_classifier_label.csv', 'r', encoding='utf-8-sig') as f:
            current_labels = [line.strip() for line in f.readlines()]
    except FileNotFoundError:
        print("⚠️  No existing label file found, creating new one")
    
    # Add new gestures
    for gesture in new_gestures:
        if gesture not in current_labels:
            current_labels.append(gesture)
            print(f"✓ Added new gesture: {gesture}")
        else:
            print(f"⚠️  Gesture '{gesture}' already exists")
    
    # Write updated labels
    with open('model/keypoint_classifier/keypoint_classifier_label.csv', 'w', encoding='utf-8-sig', newline='') as f:
        for label in current_labels:
            f.write(f"{label}\n")
    
    print(f"✓ Updated label file with {len(current_labels)} gestures")
    return len(current_labels)

def show_training_instructions(num_classes):
    """Show instructions for training new gestures"""
    print("\n" + "="*60)
    print("TRAINING INSTRUCTIONS")
    print("="*60)
    print(f"Total gestures now: {num_classes}")
    print("\nTo train new gestures:")
    print("1. Run: python app.py")
    print("2. Press 'k' to enter keypoint logging mode")
    print("3. Use number keys to collect data:")
    
    # Show which numbers to use for new gestures
    existing_gestures = []
    try:
        with open('model/keypoint_classifier/keypoint_classifier_label.csv', 'r', encoding='utf-8-sig') as f:
            existing_gestures = [line.strip() for line in f.readlines()]
    except:
        pass
    
    print("\nGesture mapping:")
    for i, gesture in enumerate(existing_gestures):
        print(f"  {i}: {gesture}")
    
    print("\nData collection tips:")
    print("- Collect 200-500 samples per gesture")
    print("- Show gestures from different angles")
    print("- Vary lighting and background slightly")
    print("- Ensure hand is clearly visible")
    
    print("\nAfter collecting data:")
    print("1. Open keypoint_classification.ipynb")
    print(f"2. Change NUM_CLASSES = {num_classes}")
    print("3. Run all cells to retrain the model")

def main():
    """Main function to add new gestures"""
    print("Hand Gesture Recognition - Add New Gestures")
    print("="*50)
    
    # Common new gestures to add
    suggested_gestures = [
        "ThumbUp",      # 👍
        "Victory",      # ✌️
        "Palm",         # 🖐️
        "Fist",         # ✊
        "Point",        # 👆
        "Rock",         # 🤘
        "Three",        # 3 fingers
        "Four",         # 4 fingers
        "Five",         # 5 fingers
        "Peace",        # Alternative peace sign
        "namaste",    # 🕷️🤟 custom gesture
        "CallMe",       # 🤙 custom gesture
        "Gun",          # 🔫 custom gesture
        "Love",         # ❤️ custom gesture
        "Stop"          # ✋ custom gesture
    ]
    
    print("Suggested new gestures:")
    for i, gesture in enumerate(suggested_gestures):
        print(f"  {i+1}: {gesture}")
    
    print("\nEnter the numbers of gestures you want to add (comma-separated):")
    print("Example: 1,2,3 for ThumbUp, Victory, Palm")
    print("Or press Enter to add all suggested gestures")
    
    user_input = input("Your choice: ").strip()
    
    if user_input == "":
        # Add all suggested gestures
        new_gestures = suggested_gestures
    else:
        try:
            # Parse user input
            indices = [int(x.strip()) - 1 for x in user_input.split(',')]
            new_gestures = [suggested_gestures[i] for i in indices if 0 <= i < len(suggested_gestures)]
        except (ValueError, IndexError):
            print("❌ Invalid input. Please enter valid numbers.")
            return
    
    if not new_gestures:
        print("❌ No gestures selected.")
        return
    
    print(f"\nAdding {len(new_gestures)} new gestures: {', '.join(new_gestures)}")
    
    # Backup existing data
    backup_existing_data()
    
    # Add new gesture labels
    num_classes = add_new_gesture_labels(new_gestures)
    
    # Show training instructions
    show_training_instructions(num_classes)
    
    print("\n" + "="*60)
    print("✅ Setup complete! You can now start training.")
    print("="*60)

if __name__ == "__main__":
    main() 