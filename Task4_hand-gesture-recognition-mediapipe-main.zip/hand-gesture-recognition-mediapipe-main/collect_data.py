#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Simplified data collection script for hand gesture training
"""

import cv2
import mediapipe as mp
import numpy as np
import csv
import os
from datetime import datetime

def collect_gesture_data():
    """Collect training data for new gestures"""
    
    # Initialize MediaPipe
    mp_hands = mp.solutions.hands
    hands = mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=2,
        min_detection_confidence=0.7,
        min_tracking_confidence=0.5,
    )
    
    # Initialize camera
    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 960)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 540)
    
    # Load existing labels
    labels = []
    try:
        with open('model/keypoint_classifier/keypoint_classifier_label.csv', 'r', encoding='utf-8-sig') as f:
            labels = [line.strip() for line in f.readlines()]
    except:
        print("Error loading labels")
        return
    
    print("=" * 60)
    print("HAND GESTURE DATA COLLECTION")
    print("=" * 60)
    print(f"Available gestures: {len(labels)}")
    for i, label in enumerate(labels):
        print(f"  {i:2d}: {label}")
    
    print("\nINSTRUCTIONS:")
    print("1. Press number key to select gesture:")
    print("   - Single digits: 0-9 for gestures 0-9")
    print("   - Double digits: Press '1' then '0' for gesture 10")
    print("   - Double digits: Press '1' then '1' for gesture 11")
    print("   - Double digits: Press '1' then '2' for gesture 12")
    print("   - Double digits: Press '1' then '3' for gesture 13")
    print("2. Show the gesture to camera")
    print("3. Hold for 1-2 seconds")
    print("4. Repeat 200+ times per gesture")
    print("5. Press 'q' to quit")
    print("6. Press 's' to show current counts")
    print("7. Press 'h' for help")
    print("=" * 60)
    
    # Track collection counts
    counts = {}
    for i in range(len(labels)):
        counts[i] = 0
    
    # Load existing data to get current counts
    try:
        with open('model/keypoint_classifier/keypoint.csv', 'r') as f:
            reader = csv.reader(f)
            for row in reader:
                if row:
                    class_id = int(row[0])
                    counts[class_id] += 1
    except:
        pass
    
    print("Current sample counts:")
    for i, count in counts.items():
        print(f"  {i:2d}: {labels[i]} - {count} samples")
    
    collecting = False
    current_gesture = None
    waiting_for_second_digit = False
    first_digit = None
    
    while True:
        ret, image = cap.read()
        if not ret:
            break
            
        image = cv2.flip(image, 1)  # Mirror display
        debug_image = image.copy()
        
        # Process image
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        results = hands.process(image_rgb)
        
        if results.multi_hand_landmarks:
            # Collect up to 2 hands
            hand_landmarks_list = []
            for hand_landmarks in results.multi_hand_landmarks:
                # Extract landmarks
                landmark_list = []
                for landmark in hand_landmarks.landmark:
                    x = min(int(landmark.x * image.shape[1]), image.shape[1] - 1)
                    y = min(int(landmark.y * image.shape[0]), image.shape[0] - 1)
                    landmark_list.append([x, y])
                # Preprocess landmarks
                processed_landmarks = preprocess_landmarks(landmark_list)
                hand_landmarks_list.append(processed_landmarks)
                # Draw landmarks
                mp.solutions.drawing_utils.draw_landmarks(
                    debug_image, hand_landmarks, mp_hands.HAND_CONNECTIONS)
            # Pad or combine for 2-hand format
            if len(hand_landmarks_list) == 1:
                # One hand: pad with zeros for the second hand
                sample = hand_landmarks_list[0] + [0.0]*42
            elif len(hand_landmarks_list) >= 2:
                # Two hands: concatenate both
                sample = hand_landmarks_list[0] + hand_landmarks_list[1]
            else:
                sample = [0.0]*84
            # Save data if collecting
            if collecting and current_gesture is not None:
                save_landmark_data(current_gesture, sample)
                counts[current_gesture] += 1
                print(f"Saved sample {counts[current_gesture]} for {labels[current_gesture]}")
        
        # Display info
        cv2.putText(debug_image, f"Press 0-9 for single digits, 1+0-3 for double digits", (10, 30),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        
        if waiting_for_second_digit:
            cv2.putText(debug_image, f"Waiting for second digit (first: {first_digit})", (10, 60),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 0), 2)
        elif collecting:
            cv2.putText(debug_image, f"Collecting: {labels[current_gesture]} ({counts[current_gesture]})", 
                       (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        else:
            cv2.putText(debug_image, "Not collecting - press number key", (10, 60),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 0, 0), 2)
        
        cv2.imshow('Hand Gesture Data Collection', debug_image)
        
        # Handle key presses
        key = cv2.waitKey(1) & 0xFF
        
        if key == ord('q'):
            break
        elif key == ord('s'):
            print("\nCurrent sample counts:")
            for i, count in counts.items():
                print(f"  {i:2d}: {labels[i]} - {count} samples")
        elif key == ord('h'):
            print("\nHELP:")
            print("Single digits (0-9): Press once")
            print("Double digits (10-13): Press '1' then the second digit")
            print("Examples:")
            print("  - For gesture 10: Press '1' then '0'")
            print("  - For gesture 11: Press '1' then '1'")
            print("  - For gesture 12: Press '1' then '2'")
            print("  - For gesture 13: Press '1' then '3'")
        elif ord('0') <= key <= ord('9'):
            digit = key - ord('0')
            
            if waiting_for_second_digit:
                # Complete double digit
                gesture_id = first_digit * 10 + digit
                if gesture_id < len(labels):
                    current_gesture = gesture_id
                    collecting = True
                    waiting_for_second_digit = False
                    first_digit = None
                    print(f"\nStarted collecting for: {labels[gesture_id]} (gesture {gesture_id})")
                else:
                    print(f"Invalid gesture ID: {gesture_id}")
                    waiting_for_second_digit = False
                    first_digit = None
            elif digit == 1:
                # Start double digit sequence
                waiting_for_second_digit = True
                first_digit = 1
                print("Press second digit (0-3) for gesture 10-13")
            else:
                # Single digit
                gesture_id = digit
                if gesture_id < len(labels):
                    current_gesture = gesture_id
                    collecting = True
                    print(f"\nStarted collecting for: {labels[gesture_id]} (gesture {gesture_id})")
                else:
                    print(f"Invalid gesture ID: {gesture_id}")
    
    cap.release()
    cv2.destroyAllWindows()
    
    print("\n" + "=" * 60)
    print("COLLECTION COMPLETE")
    print("=" * 60)
    print("Final sample counts:")
    for i, count in counts.items():
        print(f"  {i:2d}: {labels[i]} - {count} samples")
    
    total_samples = sum(counts.values())
    print(f"\nTotal samples: {total_samples}")

def preprocess_landmarks(landmark_list):
    """Preprocess landmarks for training (21x2 -> 42 values, normalized)"""
    temp_landmark_list = landmark_list.copy()
    # Convert to relative coordinates
    base_x, base_y = temp_landmark_list[0][0], temp_landmark_list[0][1]
    for i in range(len(temp_landmark_list)):
        temp_landmark_list[i][0] = temp_landmark_list[i][0] - base_x
        temp_landmark_list[i][1] = temp_landmark_list[i][1] - base_y
    # Convert to 1D list
    temp_landmark_list = [coord for point in temp_landmark_list for coord in point]
    # Normalization
    max_value = max(list(map(abs, temp_landmark_list)))
    if max_value > 0:
        temp_landmark_list = [n / max_value for n in temp_landmark_list]
    # Always return 42 values
    if len(temp_landmark_list) < 42:
        temp_landmark_list += [0.0] * (42 - len(temp_landmark_list))
    return temp_landmark_list

def save_landmark_data(gesture_id, landmark_list):
    """Save landmark data to CSV file (always 84 values)"""
    csv_path = 'model/keypoint_classifier/keypoint.csv'
    with open(csv_path, 'a', newline='') as f:
        writer = csv.writer(f)
        writer.writerow([gesture_id] + landmark_list)

if __name__ == "__main__":
    collect_gesture_data() 